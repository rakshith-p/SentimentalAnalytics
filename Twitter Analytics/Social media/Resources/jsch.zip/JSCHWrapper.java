package com.hp.td2v;


import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class JSCHWrapper {
	
	ChannelSftp channelSftp = null;
	//ChannelExec channelExec = null;
	Session session = null;
	Channel channel = null;	
	int mode = 0 ;  		//mode 0 - not defined, 1 - sftp, 2- exec
	
	
	/*
	 * Initializes a session.
	 * 
	 * Parameters
	 * host - ip address
	 * port - usually 22
	 * username 
	 * password
	 * 
	 * Return values:
	 * 	0 - successfully initialized session (but not connected)
	 *  1 - unsuccessful.
	 */
	public int setSession(String host, int port, String username, String password){
		try{
			JSch jsch = new JSch();
			session = jsch.getSession(username, host, port);
			session.setPassword(password);
			Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			return 0;
		}
		catch(JSchException ex){
			ex.printStackTrace();
			return 1;
		}
	}
	
	/*
	 * opens a channel in specified mode
	 * Parameters
	 *  modeString:
	 *  "sftp" - to send recieve files
	 *  "exec" - to send a single command to execute
	 *  
	 * Return
	 * 0 - success
	 * 1 - Invalid mode. Accepted - "sftp", "exec"
	 * 2 - Other Exception
	 */
	public int openChannel(String modeString){
		try{
			if(modeString.equals("sftp")){
				mode = 1;
				channel = session.openChannel("sftp");
				channel.connect();
				channelSftp = (ChannelSftp) channel;
				return 0;
			}
			else if(modeString.equals("exec")){
				 mode = 2;
				 channel=session.openChannel("exec");
				 return 0;
			}
			else
				return 1;	
		}
		catch(JSchException ex){
			ex.printStackTrace();
			return 2;
		}
	}

	/*
	 * Test connection
	 * 0 - success
	 * 1- fail, session not initialized, use setSession to initialize first, then use openChannel, then testConnection
	 * 2 - fail, network issue / other issue
	 */
	public int testConnection(){
		if (session == null)
			return 1;
		if(channel==null)
			return 2;
		else
			return 0;
	}
	
	/*
	 * change the working directory.
	 * 
	 *  Parameters:
	 * targetFolder - path of target folder in target server. (default - home directory of user)
	 * 
	 * Return:
	 * 0 - success
	 * 1 - fail, session not initialized
	 * 2 - fail, channel not opened
	 * 3 - fail, channel not opened in sftp mode
	 * 4 - other failure, network issue
	 */
	public int changeDir(String targetFolder){
		if(session == null)
			return 1;
		if(channel == null)
			return 2;
		if(mode != 1 || channelSftp == null)
			return 3;
		try{
			channelSftp.cd(targetFolder);
			return 0;
		}catch(Exception ex){
			return 4;
		}
	}
	
	/*
	 * Send file to server
	 * 
	 * Parameters:
	 * sourceFile - path of source file in local system.
	 * 
	 * Return:
	 * 0 - success
	 * 1 - fail, session not initialized
	 * 2 - fail, channel not opened
	 * 3 - fail, channel not opened in sftp mode
	 * 4 - other failure, network issue
	 * 
	 */
	public int sendFile(String sourceFile){
		if(session == null)
			return 1;
		if(channel == null)
			return 2;
		if(mode != 1 || channelSftp == null)
			return 3;
		try{
			File f = new File(sourceFile);
			/* - for ProgressMonitor see JSch  "put" function with SftpProgressMonitor argument -*/
			channelSftp.put(new FileInputStream(f), f.getName(), ChannelSftp.OVERWRITE);
			return 0;
		}catch(Exception ex){
			return 4;
		}
	}
	
	/*
	 * Receive file from server
	 * 
	 * Parameters:
	 * sourceFile - name of file to be created in local machine.
	 * targetFile - file to be downloaded from server
	 * 
	 * Return:
	 * 0 - success
	 * 1 - fail, session not initialized
	 * 2 - fail, channel not opened
	 * 3 - fail, channel not opened in sftp mode
	 * 4 - other failure, network issue
	 *
	 */
	public int recieveFile(String sourceFile, String targetFile){
		if(session == null)
			return 1;
		if(channel == null)
			return 2;
		if(mode != 1 || channelSftp == null)
			return 3;
		try{
			channelSftp.get(sourceFile, targetFile);
			return 0;			
		}catch(Exception ex){
			return 4;
		}
	}
	
	/*
	 * Execute a single shell command
	 * 
	 * Parmeters:
	 * command - shell command to execute
	 * 
	 * Return:
	 *  output of command as a String if success
	 *  "ERR" on failure, Reasons include: Session not initialized, channel not open, incorrect mode, network error/ other exception
	 */
	public String executeCommand(String command){
		if(session == null || channel == null /*|| channelExec == null*/ || mode!=2)
			return "ERR";		
		try{
			if(channel.isClosed())
				openChannel("exec");
			if(channel.isConnected())
				channel.disconnect();
			((ChannelExec) channel).setCommand(command);
	        channel.setInputStream(null);
            ((ChannelExec)channel).setErrStream(System.err);
             
            InputStream in=channel.getInputStream();
            channel.connect();
    
            String res = "";
            
            byte[] tmp=new byte[1024];
            while(true){
              while(in.available()>0){
                int i=in.read(tmp, 0, 1024);
                if(i<0) break;
                res = res + new String(tmp, 0, i);
              }
              if(channel.isClosed()){
                break;
              }
              try{Thread.sleep(1000);}catch(Exception ee){}
            }
            int exit_st = channel.getExitStatus();
            channel.disconnect();            
            return exit_st+"|"+res;            
		}catch(JSchException jex){
			jex.printStackTrace();
			return "1|ERR";
		}
		catch(Exception ex){
			ex.printStackTrace();
			return "1|ERR";
		}
	}

	/*
	 * disconnect channels  and session if connected
	 */
	public void disconnect()
	{
		mode = 0;
		if(channelSftp!=null && channelSftp.isConnected())
			channelSftp.disconnect();
		if(channel!=null && channel.isConnected())
			channel.disconnect();
		if(session!=null && session.isConnected())
			session.disconnect();
	}
	
	
}